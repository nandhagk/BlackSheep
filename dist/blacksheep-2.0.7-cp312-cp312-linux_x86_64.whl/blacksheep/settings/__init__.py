"""
This package contains global settings for a BlackSheep application.
"""
